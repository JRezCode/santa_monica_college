package bst;

public class HomeworkBST3NumbersApp {

	public static void main(String[] args) {
		
		BinarySearchTree<Integer> numbers = new BinarySearchTree<>();		
		
		generateNumTree(numbers);		//function populates the tree, see bottom of file
		
		//Part I - checks if 20 random values are contained in tree
		int count_of_random=0;		//a counter var		
		
		for(int i = 20; i>0;--i) {
			int random = (int)(1+Math.random()*10000);
			System.out.println("The number " + random + " is contained: " + numbers.contains(random));
		}
		
		//Part II - calculates the average value of tree
		int sum = 0;		
		int counter = 0;
		
		for (int num : numbers) {
			sum+=num;
		}

		System.out.println("The average value in the tree is " + (double)(sum/1000));	

		//Part IIb reporting the count of elements below average
		for (int num: numbers){
			if(num<(double)(sum/1000))
				counter++;
		}
		
		System.out.println("The number of elements below the average is " + counter);
		
	}

	//This static function accepts a BST and then populates it returning void
	public static void generateNumTree(BinarySearchTree<Integer> numbers) {
		for(int i = 0; i<1000; i++)
		{
			numbers.add((int)(1+Math.random()*(10000)));
		}		
	}
	
}
