package bst;

import java.util.Iterator;
import java.util.Scanner;

public class HomeworkBST2WordsApp {

	static final int TREE_SIZE=10;

	public static void main(String[] args) {
		BinarySearchTree<String> words = new BinarySearchTree<>();
		String word;
		Iterator<String> iter;

		//have to use a scanner for user prompt can't think of any other way
		Scanner input = new Scanner(System.in);
		//determine  a stop input value 'STOP'
		System.out.println("Please type/enter " + TREE_SIZE + " words for testing.");
		for(int k = 1; k<=TREE_SIZE; ++k)
		{
			System.out.println("Prompt Word " + k + ": ");
			word=input.next();
			words.add(word);	
		}

		System.out.print("Inorder:   ");
		iter = words.getIterator(BSTInterface.Traversal.Inorder);
		while (iter.hasNext())
			System.out.print(iter.next());

	}
}
