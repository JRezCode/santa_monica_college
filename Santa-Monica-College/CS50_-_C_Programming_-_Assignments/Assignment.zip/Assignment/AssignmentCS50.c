/*
Assignment 2
Student: Jonathan (reznik)
Student ID: 1654919

Description:
This program is very similar to example in the slide, what
it does is prompt user for the scores and total them then
prints the average to output.
*/

#include <stdio.h>

int main(){

int score;
double runningtotal;
double weightaverage;
float W1=.4;
float W2=.3;

printf("Calculating the weighted average of scores\n");
printf("Assignment 1:");
scanf("%d",&score);
runningtotal = score;

printf("Assignment 2:");
scanf("%d",&score);
runningtotal += score;

printf("Assignment 3:");
scanf("%d",&score);
runningtotal += score;

printf("Midterm:");
scanf("%d",&score);
weightaverage = runningtotal/3*W1 + score*W2;
//this is the average student would end with if receiving 0 on final

printf("Final:");
scanf("%d",&score);
weightaverage += score*(1-W1-W2);
//for the final the 1-w1-w2 is equal to 30% weight or .3

printf("Your average is %f\n", weightaverage);

return(0);
}