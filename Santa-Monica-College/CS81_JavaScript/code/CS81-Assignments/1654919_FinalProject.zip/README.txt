The technologies chosen for this project were plain javascript, with html/css in the browser.  There is no server action or form handling included, simply a matter of interacting with client only.  The elements of the page are there to describe and present the interactive website, so there is no need for further explanation.

Just in case, here's what I've incorporated so far:
1)Keyboard event handling (press, 1, 2 or 3, and also 'X' for one specific canvas that can be removed)
2)Mouse events- these were relatively tricky and didn't add a lot to the site.  More development to happen here.
3)Buttons such as input and radio input.  

Each of these elements presented some challenges but the overall effort was in addition to a lot of research about functionality for HTML DOM and form elements mostly focused on the function writing and I'm sure that it could be written MUCH MUCH cleaner but I chose more creative functionality over purely efficient coding in the process of programming.  Hopefully you are pleased with the effort, as I'm fairly pleased with the result at this stage, but plan to expand on this type of thing later by adding more features to it.

Thanks for the feedback and for reviewing the assignment.

By the way another thing that I feel could be improved are the lengthydescriptions for how to use the site.  This was made more difficult at the end, but even without it I think the site is in need of some description for how it works...So while I struggled there it had to be done to some degree.