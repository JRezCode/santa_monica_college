package bst;

public class HomeworkBST1 {

	public static void main(String[] args) {
		
		BinarySearchTree<Character> example = new BinarySearchTree<>();
		example.add('P');	example.add('F');
		example.add('S');	example.add('B');
		example.add('H');	example.add('R');
		example.add('Y');	example.add('G');
		example.add('T');	example.add('Z');
		example.add('W');		
		
		
		System.out.println("The size of tree is, " + example.size());
		System.out.println("The total count of leafs is, " + example.leafCount2());
		System.out.println("The ITERATIVE TEST of leafs count is, " + example.leafCount());
			
	}
}
