
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Name - Jonathan Reznik
 * Project - CS55 assignment (rock paper scissors)
 * Notes re: this program
 *  This program got complicated very quickly although the idea was for it to be simple
 *  The rules of the game are explained and a while loop is used for the play again function
 *  Something in the switch statement doesn't work for determining the winner of the game
 *      that needs to be traced.
 */

public class RockPaperScissors {
    
    public static void main(String[] args)
    {
        System.out.println("Recall the rules of the game Rock crushes scissors. Paper wraps rock. And. Scissors cut paper");        
        while (playAgain()) {
            char usermove = userChoice();
            char compmove = computerChoice();
        determineWinner(usermove, compmove);
        }
    } 
    
    public static void determineWinner(char x, char y) 
    {
        String gameResult;
        if (x==y) {
            gameResult = "There is a draw.";
        }
        else if ((x=='r' && y=='s') || (x=='s' && y=='p') || (x=='p' && y=='r')) {
            gameResult = "You win!!";
                switch(userChoice()) {
                    case 'r':
                    System.out.print("Rock crushes scissors.\n");
                    break;
                    case 'p':
                        System.out.print("Paper wraps rock.\n");
                        break;
                    case 's':
                    System.out.print("Scissors cut paper.\n"); 
                    break;
                }
        }
        else {
            gameResult = "You lose.";
        }
        System.out.println(gameResult);
    }
    
    public static boolean playAgain() {
        Scanner repeat = new Scanner(System.in);
        System.out.println("Would you like to play [y/N]: ");
        return repeat.nextLine().charAt(0)=='y';
    }
    
    public static char userChoice() {
    System.out.println("Please choose\n (r) Rock\n (p) Paper\n (s) Scissors");
    Scanner input = new Scanner(System.in);
        return input.nextLine().charAt(0);        
    }

    public static char computerChoice() {
        int rand = (int) (Math.random() * 3);
        char computer = ' ';
        switch(rand) {
            case 0:
                computer = 'r';
                break;
            case 1:
                computer = 'p';
                break;
            case 2:
                computer = 's';
                break;                
        }
        return computer;
    }
    
}
