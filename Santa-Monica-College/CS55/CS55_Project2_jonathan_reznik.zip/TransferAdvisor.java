/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Name - Jonathan Reznik
 * Project - CS55 second assignment
 *  Notes re: this program
 */
import java.util.Scanner;
        
public class TransferAdvisor {
/* -This program implements a table lookup of minimum required transfer GPA
*  -The main method is only 12 lines of actual code. A single if statement is
*    used at the end of main to compare minGPA to input.
*  -The final portion handles errors for combinations not found in the table.
*/              
      public static void main(String [] args) 
      {

          //Created a new scanner object and collects information about School/Major
          Scanner input = new Scanner(System.in);
          System.out.println("Enter The School Name: ");
          String transferCollege = input.nextLine().toUpperCase();        
          System.out.println("Enter the major (either CS, Econ or English): ");
          String collegeMajor = input.nextLine().toUpperCase();
          System.out.println("Enter your GPA: ");

          //The following line of code calls a method that returns required gpa for college/major
          double minGPA = compareGPA(transferCollege,collegeMajor);

          //using another variable to compare and output results of test condition below
          double gradePointAverage = input.nextDouble();

          if(gradePointAverage>=minGPA)
          {
              System.out.println("You could transfer to " + transferCollege + " to study " + collegeMajor);
          }
          else {
              System.out.printf("you must raise your GPA to be eligible for transfer to " + transferCollege + " by %1.2f",(minGPA - gradePointAverage));
          } 
      }
            
    public static double compareGPA(String transferCollege,String collegeMajor) {
        //This method accepts parameters for college and major, and uses this to lookup values in a table
        //Contained within this method is the table data from the assignment
        //The method returns the correct minimum gpa value based on the selection of major plus college
        
        switch (transferCollege+"+"+collegeMajor) {
            case "UCLA+CS": return(3.7);                    //String city = 'Los_Angeles';
            case "UCLA+ECON": return(3.5);                  //String city = 'Los_Angeles';
            case "UCLA+ENGLISH": return(3.2);               //String city = 'Los_Angeles';
            case "UCB+CS": return(3.8);                     //String city = 'Berkley';
            case "UCB+ECON": return(3.4);                   //String city = 'Berkley';
            case "UCB+ENGLISH": return(3.3);                //String city = 'Berkley';
            case "UCI+CS": return(3.6);                     //String city = 'Irvine';
            case "UCI+ECON": return(3.7);                   //String city = 'Irvine';
            case "UCI+ENGLISH": return(3.4);                //String city = 'Irvine';
            case "UCSD+CS": return(3.5);                    //String city = 'San_Diego';
            case "UCSD+ECON": return(3.3);                  //String city = 'San_Diego';
            case "UCSD+ENGLISH": return(3.0);               //String city = 'San_Diego';
    }
        
//Error handling for wrong school and/or major input

if (!collegeMajor.equals("CS") && !collegeMajor.equals("ECON") && !collegeMajor.equals("ENGLISH")) 

{System.out.println("This database is only for majors of CS, Econ, or English\n please try again");}

else if (!transferCollege.equals("UCLA") && !transferCollege.equals("UCB") && !transferCollege.equals("UCI") && !transferCollege.equals("UCSD"))

{System.out.println(transferCollege + " is not in the school system \n At this time information is only available for UCLA, UCB, UCI, and UCSD.");}

else {System.out.println("There is no " + collegeMajor + " at " + transferCollege);}

System.exit(0);

return(0);

    }
    
}
