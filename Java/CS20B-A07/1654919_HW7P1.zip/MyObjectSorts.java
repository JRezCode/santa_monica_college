import java.util.Comparator;

public class MyObjectSorts {

	//public static Student [] list = Driver.l.clone();   // values to be sorted

	public static void myBubbleSort(Student[] list, Comparator<Student> comp){
	    int current = 0;
	    boolean sorted = false;
	    while ((current < (list.length - 1)) && !sorted)
	    {
	    	sorted = mybubbleUp2(current, list.length - 1,list, comp);
	    	current++;
	    	}
	    }
	
	static boolean mybubbleUp2(int startIndex, int endIndex, Student[] list, Comparator<Student> comp)
	  {
	    boolean sorted = true;
	    for (int index = endIndex; index > startIndex; index--)
	      if (comp.compare(list[index], list[index-1])<0)
	      {
	        swap(index, index - 1);
	        sorted = false;
	      }
	    return sorted;
	  }
	 


  static public boolean nameIsSorted()
  // Returns true if the array values are sorted and false otherwise.
  {
    for (int index = 0; index < (Driver.l.length- 1); index++)
      if (Driver.l[index].name.compareTo(Driver.l[index + 1].name)>0)
        return false;
    return true;
  }

  static public boolean ageIsSorted()
  // Returns true if the array values are sorted and false otherwise.
  {
    for (int index = 0; index < (Driver.l.length- 1); index++)
      if (Driver.l[index].age > Driver.l[index + 1].age)
        return false;
    return true;
  }

  static public void swap(int index1, int index2)
  // Precondition: index1 and index2 are >= 0 and < SIZE.
  //
  // Swaps the integers at locations index1 and index2 of the values array. 
  {
    Student temp = Driver.l[index1];
    Driver.l[index1] = Driver.l[index2];
    Driver.l[index2] = temp;
  }
}