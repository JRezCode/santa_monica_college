import java.util.Comparator;

//created alias for Comparators to use instead of having it be anonymous for I.C.
abstract class NameSortAssistant implements Comparator<Student> { }
abstract class AgeSortAssistant implements Comparator<Student>{ }

public class Driver {

	//this is the list of objects in an array
	public static Student[] l = new Student[4];
	
	public static void main(String[] args) {

		//Now using a nice function initializes (used throughout to reinitialize as)
		initValues();
		printValues();

		//here's my comparators byAge and byName
		Comparator<Student> byAge = new AgeSortAssistant() 
		{
			public int compare(Student a, Student b) {
			return a.name.compareTo(b.name);	
			}
		};

		Comparator<Student> byName = new NameSortAssistant() 
		{	
			public int compare(Student a, Student b) {
			if(a.age>b.age)
				return 1;
			else if (a.age==b.age)
				return 0;
			else
				return -1;
			}
		};

		//Calling the static method in sorting class with list and comparator
		initValues();
		System.out.println("Values are initialized: " + "yes");
		System.out.println("****Name Bubble Sort******");
		MyObjectSorts.myBubbleSort(l,byName);
		printValues();

		initValues();
		System.out.println("Values are reinitialized: " + "yes");
		System.out.println("*****Age Bubble Sort******");
		MyObjectSorts.myBubbleSort(l,byAge);
		printValues();
	}	 
	
	static void initValues()
	  // Initializes the values array with random integers from 0 to 99.
	  {
		l[0] = new Student("Ringo",78);
		l[1] = new Student("John",40);
		l[2] = new Student("Paul",76);
		l[3] = new Student("George",58);
	  }

	static public void printValues()
	  // Prints all the values integers.
	  {
	    Student stu;
	    for (int index = 0; index < l.length; index++)
	    {
	      stu = l[index];
	      System.out.println(stu);
	      }
	    }	
}

